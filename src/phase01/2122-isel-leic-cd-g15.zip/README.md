# 2122-isel-leic-cd-g15

> Digital Communications project of group 15 from LEIC41D class.

---

## Authors

- [André Páscoa](https://github.com/devandrepascoa)
- [André Jesus](https://github.com/Andre-J3sus)
- [Nyckollas Brandão](https://github.com/Nyckoka)

Professor: Eng. Artur Ferreira

ISEL<br>
Bachelor in Computer Science and Computer Engineering<br>
Digital Communications - LEIC41D - Group 15<br>
Summer Semester of 2021/2022
